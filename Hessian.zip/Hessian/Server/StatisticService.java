/**
 * Created by ������� on 20.06.2015.
 */
public interface StatisticService {

    public long allStat();
    public double addStat();
    public double getStat();
    public void clear();
}
